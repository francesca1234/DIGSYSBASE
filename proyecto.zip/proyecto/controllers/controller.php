<?php

class MvcController{

	#LLAMADA A LA PLANTILLA
	#-------------------------------------

	public function pagina(){	
		
		include "views/template.php";
	
	}

	#ENLACES
	#-------------------------------------

	public function enlacesPaginasController(){

		if(isset( $_GET['action'])){
			
			$enlaces = $_GET['action'];
		
		}

		else{

			$enlaces = "index";
		}

		$respuesta = Paginas::enlacesPaginasModel($enlaces);

		include $respuesta;

	}

	#REGISTRO DE USUARIOS
	#------------------------------------
	public function registroUsuarioController(){

		if(isset($_POST["registroaprendiz"])){
			
			$datosController = array( "cedula"=>$_POST['DocumentoU'], 
									  "nombres"=>$_POST['NombreU'],
									  "apellidos"=>$_POST['ApellidoU'],
									  "tipodoc"=>$_POST['tipdoc'],
									  "genero"=>$_POST['genero'],
									   "benefic"=>$_POST['benefi'],									 
								      "dir"=>$_POST['direccion'],								      
								      "tel"=>$_POST['tel'],								     
								      "email"=>$_POST['email']);
								      
									  
			//var_dump($datosController);
			$respuesta = Datos::registroUsuarioModel($datosController,"aprendiz");
			
			
			if($respuesta == "success"){

				echo "<script>alert('Se registro correctamente')</script>";

			}

			else{

				echo "<script>alert('El aprendiz ya se encuentra registrado')</script>";
			}
			
		}

	}

	#INGRESO DE USUARIOS
	#------------------------------------
	public function ingresoUsuarioController(){

		if(isset($_POST["usuarioIngreso"])){

			$datosController = array( "usuario"=>$_POST["usuarioIngreso"], 
								      "password"=>$_POST["passwordIngreso"]);
			$respuesta = Datos::ingresoUsuarioModel($datosController, "usuario");
			
			if($respuesta["documento"] == $_POST["usuarioIngreso"] && $respuesta["clave"] == $_POST["passwordIngreso"]){

				session_start();

				$_SESSION["validar"] = true;

				header("location:index.php?action=usuarios");

			}

			else{

				header("location:index.php?action=fallo");

			}

		}	

	}

	#VISTA DE USUARIOS
	#------------------------------------

	public function vistaUsuariosController(){

		$respuesta = Datos::vistaUsuariosModel("usuarios");

		#El constructor foreach proporciona un modo sencillo de iterar sobre arrays. foreach funciona sólo sobre arrays y objetos, y emitirá un error al intentar usarlo con una variable de un tipo diferente de datos o una variable no inicializada.

		foreach($respuesta as $row => $item){
		echo'<tr>
				<td>'.$item["nombre"]." ".$item["apellidos"].'</td>
				<td>'.$item["documento"].'</td>
				<td>'.$item["beneficio"].'</td>
				<td>'.$item["direccion"].'</td>
				<td>'.$item["telefono"].'</td>
				<td>'.$item["email"].'</td>
				<td><a href="index.php?action=editar&id='.$item["documento"].'"><button>Editar</button></a></td>
				<td><a href="index.php?action=usuarios&idBorrar='.$item["documento"].'"><button>Borrar</button></a></td>
			</tr>';

		}

	}

	#VISTA DE USUARIOS ANDROID
	#------------------------------------

	public function vistaUsuariosAndroidController(){

		/*$respuesta = DatosAndroid::vistaUsuariosModel("usuarios");
		var_dump($respuesta);
		#El constructor foreach proporciona un modo sencillo de iterar sobre arrays. foreach funciona sólo sobre arrays y objetos, y emitirá un error al intentar usarlo con una variable de un tipo diferente de datos o una variable no inicializada.

		foreach($respuesta as $row => $item){
		echo'<tr>
				<td>'.$item["usuario"].'</td>
				<td>'.$item["passw"].'</td>
				<td>'.$item["mail"].'</td>
				<td><a href="index.php?action=editar&id='.$item["id"].'"><button>Editar</button></a></td>
				<td><a href="index.php?action=usuarios&idBorrar='.$item["id"].'"><button>Borrar</button></a></td>
			</tr>';
			}
			*/

			

			$datosController = array( "usuario"=>$_REQUEST["usu"], 
								      "password"=>$_REQUEST["pas"]);

			$respuesta = DatosAndroid::ingresoUsuarioModel($datosController, "usuarios");

			//var_dump($respuesta);

			echo json_encode($respuesta);
			


	}

	#EDITAR USUARIO
	#------------------------------------

	public function editarUsuarioController(){

		$datosController = $_GET["id"];
		$respuesta = Datos::editarUsuarioModel($datosController, "usuario");

		echo'<input type="hidden" value="'.$respuesta["id"].'" name="idEditar">

			 <input type="text" value="'.$respuesta["usuario"].'" name="usuarioEditar" required>

			 <input type="text" value="'.$respuesta["passw"].'" name="passwordEditar" required>

			 <input type="email" value="'.$respuesta["mail"].'" name="emailEditar" required>

			 <input type="submit" value="Actualizar">';

	}

	#ACTUALIZAR USUARIO
	#------------------------------------
	public function actualizarUsuarioController(){

		if(isset($_POST["usuarioEditar"])){

			$datosController = array( "id"=>$_POST["idEditar"],
							          "usuario"=>$_POST["usuarioEditar"],
				                      "password"=>$_POST["passwordEditar"],
				                      "email"=>$_POST["emailEditar"]);
			
			$respuesta = Datos::actualizarUsuarioModel($datosController, "usuarios");

			if($respuesta == "success"){

				header("location:index.php?action=cambio");

			}

			else{

				echo "error";

			}

		}
	
	}

	#BORRAR USUARIO
	#------------------------------------
	public function borrarUsuarioController(){

		if(isset($_GET["idBorrar"])){

			$datosController = $_GET["idBorrar"];
			
			$respuesta = Datos::borrarUsuarioModel($datosController, "aprendiz");

			if($respuesta == "success"){

				header("location:index.php?action=usuarios");
			
			}

		}
     }
	

	#GENERAR PDF
	public function pdfcontroller(){

		if(isset($_POST["fechainicial"])){
			
			$datosController = array( "inicial"=>$_POST["fechainicial"], 
									  "final"=>$_POST["fechafinal"]);

			
			//var_dump($datosController);
			$respuesta = Datos::pdfmodel($datosController);

				 foreach ($respuesta as $valores => $columnas) {
				
						 echo   '<tr>
			           				 <td>'.$columnas['0'].'</td>	 
			           				 <td>'.$columnas['1']."  ".$columnas['2'].'</td>
			           				 <td>'.$columnas['3'].'</td>
			           				 <td>'.$datosController['inicial']." - ".$datosController['final'].'</td>
			            			 <td>'.$columnas['4'].'</td>
			            			 <td>'.'$ '.$columnas['5'].'</td>
			            			 <td>'.'$ '.$columnas['6'].'</td>
			          			</tr>';
				}


       }
   }

   #LLENAR SELECT
	#------------------------------------

	public function listaselcontroller(){

		$respuesta = Datos::listamodel("codfuncionales");

		#El constructor foreach proporciona un modo sencillo de iterar sobre arrays. foreach funciona sólo sobre arrays y objetos, y emitirá un error al intentar usarlo con una variable de un tipo diferente de datos o una variable no inicializada.
		//var_dump($respuesta);
		
		foreach($respuesta as $row => $item){
		echo'<option value="'.$item['codfuncional'].'">'.$item['codfuncional']." - ". $item['areafunc'].'</option>';

		}

	}



}

?>