<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bonos</title>	
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="views/materialize/css/materialize.min.css">
	<link rel="stylesheet" href="views/materialize/css/estilo.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	

</head>

<body>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="views/materialize/js/materialize.min.js"></script>
	<script type="text/javascript" src="materialize/js/materialize.min.js"></script>
	<script type="text/javascript" src="materialize/js/jquery.table2excel.js"></script>

<script>
	$(document).ready(function(){
		$('select').material_select();
	});

</script>





<?php 
include "modules/navegacion.php"; 

?>


<section>

<?php 

$mvc = new MvcController();
$mvc -> enlacesPaginasController();

 ?>

</section>
	
</body>

</html>