<div class="container">
	<div class="row">
		

	</div>


</div> 
	<div class="container"> 
		<div class="row">
		  <div class="col s4"></div>	
		   <div class="col s4">
						<center><h5>Registro Diario</h5></center>		   		
		   		<form method="post" >
				
					<label>Fecha Inicial</label>
						<input type="text" class="datepicker" name="fechainicial">

							<script type="text/javascript">
	
									$('.datepicker').pickadate({
									    selectMonths: true, // Creates a dropdown to control month
									    selectYears: 15, // Creates a dropdown of 15 years to control year,
									    today: 'Hoy',
									    clear: 'Limpiar',
									    close: 'Aceptar',
									    closeOnSelect: false, // Close upon selecting a date,
									    format: 'yyyy-mm-dd'
									  });
							</script>

					<label>Fecha Final</label>
						
						<input type="text" class="datepicker" name="fechafinal" >

							<script type="text/javascript">
	
									$('.datepicker').pickadate({
									    selectMonths: true, // Creates a dropdown to control month
									    selectYears: 15, // Creates a dropdown of 15 years to control year,
									    today: 'Hoy',
									    clear: 'Limpiar',
									    close: 'Aceptar',
									    closeOnSelect: false, // Close upon selecting a date,
									    format: 'yyyy-mm-dd'
									  });
							</script>							
     
						<center><input type="submit" class="btn waves-effect waves-light" value="Consultar"></center>
						<br>
						<center><input type="button" class="btn waves-effect waves-light" value="Excel" id="btnexcel" onclick=""></center>

			   </form>
		   </div>	 	
		   		<div class="col s4"></div>
		</div>	
	</div>

<div class="container">

		<div class="row">
			<div class="col s12">
				
			</div>	  

	
		</div>		 	

</div>	

<div class="row">

	<div class="col s2"></div>	
		   		
		   		<div class="col s8">

		   		<table class="table highlight bordered centered" id="table2">
							
					    <thead>
					          <tr>
					              <th>CODIGOSAP</th>
					              <th>NOMBRE COMPLETO</th>
					              <th>A.FUNCIONAL</th>
					              <th>FECHA CORTE</th>
					              <th>CANTIDAD</th>
					              <th>VR.UNITARIO</th>
					              <th>TOTAL</th>
					          </tr>   
					    </thead>

						<tbody>    
								<?php
									$generar = new MvcController();
									$generar -> pdfcontroller();							
								?>	

						</tbody>

				</table>
			   			
		   	 	</div>	 	

	<div class="col s2"></div>	

</div>

