<?php

session_start();

if(!$_SESSION["validar"]){

	header("location:index.php?action=ingresar");

	exit();

}

?>

</div> 
	<div class="container"> 
		<div class="row">
		  <div class="col m3"></div>	
		   <div class="col m12">
	<table class="bordered" >
		<center><h4>Usuarios Registrados</h4></center>
		<thead>
			
			<tr>
				<th>Aprendiz</th>
				<th>Documento</th>
				<th>Tipo de beneficio</th>
				<th>Direccion</th>
				<th>Telefono</th>
				<th>Correo</th>
				<th>Actualizar</th>
				<th>Eliminar</th>

			</tr>

		</thead>

		<tbody>
			
			<?php

			$vistaUsuario = new MvcController();
			$vistaUsuario -> vistaUsuariosController();
			$vistaUsuario -> borrarUsuarioController();

			?>

		</tbody>

	</table>
			</div>	 	
		<div class="col m3"></div>
	</div>	
</div>		

<?php

if(isset($_GET["action"])){

	if($_GET["action"] == "cambio"){

		echo "Cambio Exitoso";
	
	}

}

?>




