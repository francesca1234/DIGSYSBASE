	 <ul id="dropdown1" class="dropdown-content">
	 	 <li><a href="index.php?action=modregistrodiario">Diario</a></li>
	  	<li><a href="#!">Facturas</a></li>
	  	<li class="divider"></li>
	  	<!--<li><a href="#!">three</a></li>-->
	</ul>

  <div class="navbar-fixed">
  <nav>
	<div class="nav-wrapper #00897b teal darken-1">
		<a href="#" class="brand-logo">SENA</a>
		<ul id="nav-mobile" class="right hide-on-med-and-down">
			<li><a href="index.php">Registro</a></li>
			<!-- <li><a class="dropdown-button" href="#!" data-activates="dropdown1">Informes<i class="material-icons right">arrow_drop_down</i></a></li>	 -->		
			<li><a href="index.php?action=ingresar">Login</a></li>
			<li><a href="index.php?action=usuarios">Usuarios</a></li>
			<li><a href="index.php?action=salir">Salir</a></li>

		</ul>
	</div>	
</nav>
</div>
