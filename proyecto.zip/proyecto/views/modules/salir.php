<?php

session_start();
session_destroy();

?>

<h4>¡Has cerrado sesión!</h4>