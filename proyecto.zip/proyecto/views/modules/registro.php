</div> 
	<div class="container"> 
		<div class="row">
		  	<center><h6> Formulario de Registro </h6></center>	
		
		</div>	
		<form method="post">
			<div class="row">
				<div class="col s6">
					
					<label for="sel1">Nombres del Aprendiz</label>
						<input type="text" placeholder="Nombres" name="NombreU" required>
					<label for="sel1">Apellidos del Aprendiz</label>	
						<input type="text" placeholder="Apellidos" name="ApellidoU" required>

					<div class="form-group">
					    <label for="sel1">Tipo de Documento</label>
							  <select class="form-control" name="tipdoc">
                                 <option value="1">Tarjeta de Identidad</option>
								    <option value="2">Cedula de Ciudadania</option>
								     <option value="3">Cédula de Extranjería</option>
								    <option value="4">Pasaporte</option>						    
							 </select>
					</div>	

					<label for="sel1">Cedula de Ciudadania</label>
					
					<input type="number" placeholder="Cedula de Ciudadania" name="DocumentoU" required>
					<div class="form-group">
						  <label for="sel1">Genero</label>
								  <select class="form-control" name="genero" id="genero">
									    <option value="1">MASCULINO</option>
									    <option value="2">FEMENINO</option>
									   						    						    
								 </select>
					
					    </div>
  					
				</div>



				<div class="col s6">
												
						<div class="form-group">
						  <label for="sel1">Beneficio</label>
								 <select class="form-control" name="benefi" id="benefi">
									    <option value="1">TRANSPORTE</option>
									    <option value="2">ALMUERZO</option>						    
								 </select>
					    </div>	    

							

					    <label for="sel1">Dirección del Aprendiz</label>
					<input type="text" placeholder="Dirección" name="direccion" id="direccion" required>
					
					 <label for="sel1">Telefono del Aprendiz</label>
					<input type="number" placeholder="Telefono" name="tel" id="tel" required>
					 <label for="sel1">Correo del Aprendiz</label>
					<input type="text" placeholder="Correo" name="email" id="email" required>
					

				</div>

			</div>
		
			<div class="row">
				<center><input type="submit" name="registroaprendiz" class="btn waves-effect waves-light" value="Registrar"></center>
			</div>

		</form>	
	</div>
</div>				

<?php

$registro = new MvcController();
$registro -> registroUsuarioController();

if(isset($_GET["action"])){

	if($_GET["action"] == "ok"){

		
		echo "Registro Exitoso";
	
	}

}

?>
