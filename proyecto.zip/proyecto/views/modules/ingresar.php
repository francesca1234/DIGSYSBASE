<div class="container">
	<div class="row"></div>

</div> 
	<div class="container"> 
		<div class="row">
		  <div class="col m4"></div>	
		   	<div class="col m4">
				<div class="form">
						<center><h4>Iniciar Sesion</h4></center>		   		
					   		<form method="post" >
							
									<input type="text" placeholder="Usuario" name="usuarioIngreso" required>

									<input type="password" placeholder="Contraseña" name="passwordIngreso" required>

									<center><input type="submit" class="btn waves-effect waves-light" value="Aceptar"></center>
						   </form>
			    </div>		
		   </div>	 	
		   		<div class="col m4"></div>
		</div>	
	</div>

<?php

$ingreso = new MvcController();
$ingreso -> ingresoUsuarioController();


if(isset($_GET["action"])){

	if($_GET["action"] == "fallo"){

		echo "<script>alert('Usuario o Contraseña errada')</script>";
	
	}

}

?>