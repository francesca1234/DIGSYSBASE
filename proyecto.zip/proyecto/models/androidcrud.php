<?php

require_once "conexion.php";


class DatosAndroid  extends Conexion{
	#VISTA DE USUARIO
	#--------------------------------------------------
	public function vistaAndroidModel($tbala){

		$stmt = Conexion::conectar()->prepare("SELECT usuario, passw, mail FROM $tabla");	
		$stmt->execute();

		#fetchAll(): Obtiene todas las filas de un conjunto de resultados asociado al objeto PDOStatement. 
		return $stmt->fetchAll();

		$stmt->close();


	}



}


