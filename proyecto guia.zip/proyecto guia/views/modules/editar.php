<?php

session_start();

if(!$_SESSION["validar"]){

	header("location:index.php?action=ingresar");

	exit();

}

?>


</div> 
	<div class="container"> 
		<div class="row">
		  <div class="col m4"></div>	
		   <div class="col m4">
				<center><h4>Modificar</h4></center>		   
					<form method="post">
	
						<?php

						$editarUsuario = new MvcController();
						$editarUsuario -> editarUsuarioController();
						$editarUsuario -> actualizarUsuarioController();

						?>

					</form>
			</div>	 	
		<div class="col m4"></div>
	</div>	
</div>			


