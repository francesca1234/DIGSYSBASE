<?php

		require_once "conexion.php";
		$pdo = Conexion::conectar();

		
	    $cc=$_REQUEST['codem'];	
	    

	    //echo $usuario;
			//$link = new PDO("mysql:host=localhost;dbname=casino","root","root");
			
			//mysql_query("SET NAMES 'utf8'");
			$registro = array();	
			$stm=("INSERT INTO registrodiario (codemp,fecha_hora,cant,estado) VALUES ($cc,localtime(),'1','1')");
			$q = $pdo->prepare($stm);
        	$q->execute(array($cc,'localtime()','1','1')); 
			
			//$cons=mysql_query($res);
			//$stm->bindParam(':codemp', $cc);
			
			//$cc='123';

	//		$stm->execute();
		
		//$registro["resultado"]=true;		
		//$registro["mensaje"]="Usuario creado";
			
				echo json_encode($q);
				
			

			/*$link = new PDO("mysql:host=localhost;dbname=casino","root","root");
			$res=$link->prepare("INSERT INTO registrodiario (codemp) VALUES (:codemp)");
			$consulta=mysql_query($res);
				echo "Registro almacenado";*/

			/*$sentencia = $con->prepare("INSERT INTO Producto (codigo, descripcion) VALUES (:codigo, :descripcion)");
			$sentencia->bindParam(':codigo', $codigo);
			$sentencia->bindParam(':descripcion', $descripcion);*/

			//$respuesta = DatosAndroid::ingresoUsuarioModel($datosController, "usuarios");

			
			

?>